const express = require('express')
const mongoose = require('mongoose')
// const Product = require('./models/product.model')
const productRouted = require('./routes/product.route')
const app = express()
const port = 3000;

app.use(express.json())

//create Product
// app.post('/api/products', async (req, res) => {
//     try {
//         const product = await Product.create(req.body)
//         res.json(product)
//     } catch (error) {
//         res.send.json({ message: error.message })
//     }
// })

app.use('/',productRouted)

//get All product
// app.get('/api/products', async (req, res) => {
//     try {
//         const product = await Product.find({});
//         res.json(product)
//     } catch (error) {
//         res.send.json({ message: error.message })
//     }
// })

//get Product By Id
// app.get('/api/product/:id', async (req, res) => {
//     try {
//         const { id } = req.params;
//         const product = await Product.findById(id);
//         res.json(product)
//     } catch (error) {
//         res.send.json({ message: error.message })
//     }
// })

//update product
// app.put('/api/product/:id', async (req, res) => {
//     try {
//         const { id } = req.params
//         const product = await Product.findByIdAndUpdate(id, req.body);
//         if (!product) {
//             return res.json({ message: 'No such product' })
//         }
//         const updateProduct = await product.findById(id)
//         res.json(updateProduct)
//     } catch (error) {
//         res.json({ message: error.message })
//     }
// })

//delete Product
// app.delete('/api/product/:id', async (req, res) => {
//     try {
//         const { id } = req.params
//         const product = await Product.findByIdAndDelete(id)
//         if (!product) {
//             return res.json({ message: 'The product is not found!' })
//         }
//         res.json({ message: "product Deleted Successfully" });
//     } catch (error) {
//         res.json({ message: error.message });
//     }
// })

mongoose.connect("mongodb://127.0.0.1:27017/product")
    .then(() => {
        console.log('Connected To DB');
    })
    .catch(() => {
        console.log('Connection Failed');
    })

app.listen(port, () => {
    console.log(`Server Is Running on Port ${port}`);
})

