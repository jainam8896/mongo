const express = require('express')
const route = express.Router()
const productController = require('../controller/product.controller')

route.get('/api/products',productController.product)
route.post('/api/products',productController.createProduct)

module.exports = route