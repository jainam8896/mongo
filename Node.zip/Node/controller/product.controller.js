// const Product = require('./models/product')
const Product = require('../models/product.model')

const product = async (req, res) => {
    try {
        const product = await Product.find({})
        res.json(product)
    } catch (error) {
        res.json({ message: error.message })
    }
}

const createProduct = async (req, res) => {
    try {
        const product = await Product.create(req.body)
        res.json(product)
    } catch (error) {
        res.json({ message: error.message })
    }
}

module.exports = { product, createProduct }